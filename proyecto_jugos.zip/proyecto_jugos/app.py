from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# Conexión a la base de datos
db = mysql.connector.connect(
    host="localhost",
    user="tu_usuario",
    password="tu_contraseña",
    database="negocio_jugos"
)

# Página de inicio con los productos
@app.route('/')
def index():
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM productos")
    productos = cursor.fetchall()
    cursor.close()
    return render_template('index.html', productos=productos)

# Añadir un pedido
@app.route('/agregar_pedido', methods=['POST'])
def agregar_pedido():
    cliente_id = request.form['cliente_id']
    producto_id = request.form['producto_id']
    cantidad = int(request.form['cantidad'])
    
    cursor = db.cursor()
    cursor.execute("INSERT INTO pedidos (cliente_id, producto_id, cantidad) VALUES (%s, %s, %s)",
                   (cliente_id, producto_id, cantidad))
    db.commit()
    cursor.close()
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)
