const carritoContenido = document.getElementById('carrito-contenido');
const carritoTotal = document.getElementById('carrito-total');
let carrito = [];

function agregarAlCarrito(nombre, precio, cantidad) {
    if (!cantidad || cantidad < 1) {
        alert("Por favor, ingrese una cantidad válida.");
        return;
    }

    let productoEnCarrito = carrito.find(item => item.nombre === nombre);
    if (productoEnCarrito) {
        productoEnCarrito.cantidad += cantidad;
    } else {
        carrito.push({ nombre, precio, cantidad });
    }
    actualizarCarrito();
}

function actualizarCarrito() {
    carritoContenido.innerHTML = '';
    let total = 0;

    carrito.forEach(item => {
        let subtotal = item.precio * item.cantidad;
        total += subtotal;

        const itemElemento = document.createElement('div');
        itemElemento.classList.add('carrito-item');
        itemElemento.innerHTML = `${item.nombre} - Cantidad: ${item.cantidad} - Subtotal: $${subtotal}`;
        carritoContenido.appendChild(itemElemento);
    });

    carritoTotal.innerHTML = `Total: $${total}`;
}

function realizarPedido() {
    if (carrito.length === 0) {
        alert("El carrito está vacío. Añade productos antes de realizar el pedido.");
        return;
    }

    const nombreCliente = document.getElementById('nombre-cliente').value;
    const direccionCliente = document.getElementById('direccion-cliente').value;
    const metodoPago = document.getElementById('metodo-pago').value;

    if (!nombreCliente || !direccionCliente) {
        alert("Por favor, ingrese su nombre y dirección.");
        return;
    }

    let pedidoResumen = "Resumen de tu pedido:\n";
    carrito.forEach(item => {
        pedidoResumen += `Producto: ${item.nombre}, Cantidad: ${item.cantidad}, Subtotal: $${item.precio * item.cantidad}\n`;
    });

    pedidoResumen += `\nTotal: ${carritoTotal.textContent}`;
    pedidoResumen += `\n\nNombre: ${nombreCliente}\nDirección: ${direccionCliente}\nMétodo de pago: ${metodoPago}`;

    alert(pedidoResumen);

    carrito = [];
    actualizarCarrito();
}
